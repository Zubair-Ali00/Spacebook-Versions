import React from 'react';
import { Text, View, StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  center: {
    alignItems: 'center'
  }
})



const spPostInput = (props) => {
    return (
        //add function to get total posts from props.username

        <View>
            <View>

                <View>

                

                </View>

                <View>
                    <Text>
                         My Name
                    </Text>

                    <Text>
                        date now
                    </Text>
                    
                </View>

            </View>
            
            <View>

            <TextInput
                //style={styles.input}
                //onChangeText={onChangeText}
                //value={text}
            />
                
            </View>
        </View>
    );
}


export default spPostInput;